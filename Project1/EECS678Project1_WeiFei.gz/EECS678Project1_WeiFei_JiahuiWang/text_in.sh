ls 
ls -l 
ls -l | wc 
exit